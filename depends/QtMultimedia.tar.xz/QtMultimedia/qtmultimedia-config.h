#define QT_NO_ALSA 
#define QT_NO_OPENAL 
#define QT_NO_PULSEAUDIO 
